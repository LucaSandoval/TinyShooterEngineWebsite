import tinyshooterengine
import time, random, re

game_width = 800
game_height = 800

# Set up application and scene for testing
application = tinyshooterengine.Application(game_width, game_height)
# "./scenes/test_scene.txt"
scene = tinyshooterengine.Scene(application)

current_time = time.time()
tile_x = 5
tile_y = 5
move_time = 0.2
move_timer = move_time
pallet_selection_id = 0

# Load main scene
application.AddScene(scene, "Main")
application.LoadScene("Main")

# Create unique scene save path
scene_prefixes = ["epic", "awesome", "cool", "wonderful", "silly", "spooky", "wacky", "goofy", "troublesome"]
scene_sufixes = ["playground", "arena", "battlefield", "lab", "base", "warzone", "dungeon", "cave", "mountain"]
scene_id = random.choice(scene_prefixes) + "_" + random.choice(scene_sufixes) + str(int(random.uniform(1, 9999)))
print("Unique scene id: " + str(scene_id))


# Set up background
for i in range(14):
    for x in range(14):
        new_tile = scene.SpawnPrefab("./Assets/prefabs/LE_tile.txt")
        new_tile.Transform().SetPosition(i * 60, x * 60)

# Cursor
cursor = scene.SpawnPrefab("./Assets/prefabs/LE_highlight_tile.txt")
cursor_transform = cursor.Transform()

# Set up UI
le_title = scene.SpawnPrefab("./Assets/prefabs/LE_title.txt")
le_title.Transform().SetPosition(0, -20)

le_brush = scene.SpawnPrefab("./Assets/prefabs/LE_brush.txt")
le_brush.Transform().SetPosition(655, 605)
le_brush_sprite = le_brush.GetComponent(tinyshooterengine.ComponentType.SpriteComponent)

le_controls = scene.SpawnPrefab("./Assets/prefabs/LE_controls.txt")
le_controls.Transform().SetPosition(0, 530)

brush_sprites = ["./Assets/sprites/engines_brush1.bmp", "./Assets/sprites/engines_brush2.bmp", "./Assets/sprites/engines_brush3.bmp", "./Assets/sprites/engines_brush4.bmp", "./Assets/sprites/engines_brush5.bmp"]
pallet = {0 : "./Assets/prefabs/box.txt", 1 : "./Assets/prefabs/test_enemy.txt", 2 : "./Assets/prefabs/strong_enemy.txt", 3 : "./Assets/prefabs/player.txt", 4 : "ERASER"}
scene_objects = {}

def save_scene():
    global scene_id
    file_content = ""

    # Construct scene file
    for key in scene_objects:
        value = scene_objects[key]
        # Extract object coords
        pattern = r"{(\d+), (\d+)}"
        match = re.findall(pattern, key)
        x, y = match[0]
        prefab_str = "[PREFAB] " + value[0] + " " + str((int(x) * 60)) + " " + str((int(y) * 60)) + "\n"
        file_content += prefab_str


    with open("./Assets/scenes/" + scene_id + ".txt", 'w') as file:
        file.write(file_content)
    return

# Game Loop
while True:

    # Calculate delta time
    new_time = time.time()
    delta_time = new_time - current_time
    current_time = new_time

    if move_timer > 0:
        move_timer -= delta_time

    # Set cursor position
    cursor_transform.SetPosition(tile_x * 60, tile_y * 60)
    if application.WKeyPressed() and move_timer <= 0:
        tile_y -= 1
        move_timer = move_time
    if application.DKeyPressed() and move_timer <= 0:
        tile_x += 1
        move_timer = move_time
    if application.SKeyPressed() and move_timer <= 0:
        tile_y += 1
        move_timer = move_time
    if application.AKeyPressed() and move_timer <= 0:
        tile_x -= 1
        move_timer = move_time
    if tile_x < 0:
        tile_x = 0
    if tile_x > 12:
        tile_x = 12
    if tile_y < 0:
        tile_y = 0
    if tile_y > 12:
        tile_y = 12

    # Change pallete selection
    if application.UpKeyPressed() and move_timer <= 0:
        pallet_selection_id += 1
        move_timer = move_time
    if application.DownKeyPressed() and move_timer <= 0:
        pallet_selection_id -= 1
        move_timer = move_time
    if pallet_selection_id >= len(pallet):
        pallet_selection_id = 0
    if pallet_selection_id < 0:
        pallet_selection_id = len(pallet) - 1

    le_brush_sprite.SetSprite(brush_sprites[pallet_selection_id])

    if application.SpaceKeyPressed():
        position_key = "{" + str(tile_x) + ", " + str(tile_y) + "}"

        if pallet_selection_id == 4:
            # Eraser logic
            if position_key in scene_objects:
                to_delete = scene_objects.pop(position_key)
                scene.DestroyGameObject(to_delete[1])
        else:
            # Placement logic
            if position_key not in scene_objects:
                new_obj = scene.SpawnPrefab(pallet[pallet_selection_id])
                scene_objects[position_key] = [pallet[pallet_selection_id], new_obj]
                new_obj.Transform().SetPosition(tile_x * 60, tile_y * 60)

    # Save scene to file
    if application.RShiftKeyPressed() and move_timer <= 0:
        print("Saved scene!")
        save_scene()
        move_timer = move_time

    # Game quit
    if application.EscapeKeyPressed():
        break


    # Tick application
    application.Tick(delta_time)

application.Shutdown()