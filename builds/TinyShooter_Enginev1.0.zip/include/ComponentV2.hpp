#pragma once

class ApplicationV2;
class GameObjectV2;

/**
 * An enum representing the type of a component in TinyShooter Engine.
*/
enum ComponentType {
    TransformComponent,
    SpriteComponent,
    SquareColliderComponent,
    MovementComponent
};

/**
 * ComponentV2 is an abstract class representing a Component on a GameObject. ComponentV2
 * has been extended to support a handful of basic components. 
*/
class ComponentV2{
public:
    /**
     * Basic constructor. Each component requires a reference to the TinyShooter Engine Application
     * running your game ( \p application ) and the GameObject it is attatched to ( \p game_object ).
    */
    ComponentV2(ApplicationV2* application, GameObjectV2* game_object);
    /**
     * Basic destructor. 
    */
    ~ComponentV2();

    /**
     * The Input method for this component, takes in \p delta_time , 
     * the real time in seconds between the previous and current call of the application's Tick().
    */
    virtual void Input(float delta_time) = 0;
    /**
     * The Update method for this component, takes in \p delta_time , 
     * the real time in seconds between the previous and current call of the application's Tick().
    */
    virtual void Update(float delta_time) = 0;
    /**
     * The Render method for this component.
    */
    virtual void Render() = 0;

    /**
     * Returns a ComponentType representing the type of this component.
    */
    virtual ComponentType GetType() = 0;

    /**
     * Returns a pointer to the application given in this component's constructor. 
    */
    ApplicationV2* GetApplication();
    /**
     * Returns a pointer to the GameObject this component is attatched to. 
    */
    GameObjectV2* GetGameObject();
private:
    ApplicationV2* m_application;
    GameObjectV2* m_game_object;
};