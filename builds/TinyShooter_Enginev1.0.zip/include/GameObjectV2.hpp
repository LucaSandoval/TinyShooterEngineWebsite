#pragma once

#include "ComponentV2.hpp"
#include "TransformComponentV2.hpp"
#include "SpriteComponentV2.hpp"
#include "SquareColliderComponentV2.hpp"
#include "MovementComponentV2.hpp"
#include <vector>
#include <unordered_map>
#include <string>

class ApplicationV2;

/**
 * GameObjectV2 is a class representing a GameObject in TinyShooter Engine. GameObjects are the most basic 
 * object in a TinyShooter Engine game, capable of having several different ComponentV2 attatchments that 
 * provide its functionality. All GameObjectV2 have a TransformComponentV2 by default.
*/
class GameObjectV2 {
public:
    /**
     * Basic constructor. \p application specifies the application this GameObject belongs to.  
    */
    GameObjectV2(ApplicationV2* application);
    /**
     * Basic destructor. Handles dealocating components attatched to this GameObject.
    */
    ~GameObjectV2();
    /**
     * The Input method for this GameObject, takes in \p delta_time , 
     * the real time in seconds between the previous and current call of the application's Tick().
     * This will call Input() on all attatched Components.
    */
    void Input(float delta_time);
    /**
     * The Update method for this GameObject, takes in \p delta_time , 
     * the real time in seconds between the previous and current call of the application's Tick().
     * This will call Update() on all attatched Components.
    */
    void Update(float delta_time);
    /**
     * The Render method for this GameObject.
     * This will call Render() on all attatched Components.
    */
    void Render();
    /**
     * Adds a new component to this GameObject, specified by the \p type .
    */
    void AddComponent(ComponentType type);
    /**
     * Returns a pointer to the component attached to this GameObject given by the \p type.
    */
    ComponentV2* GetComponent(ComponentType type);
    /**
     * Returns a pointer to the TransformComponentV2 of this GameObject. All GameObjects have a 
     * Transform component by default.
    */
    TransformComponentV2* Transform();
    /**
     * Sets the name of this GameObject to the given \p name .
    */
    void SetName(std::string name);
    /**
     * Returns the name of this GameObject.
    */
    std::string GetName();
    /**
     * Adds a \p tag to this GameObject. A GameObject may have any ammount of tags.
    */
    void AddTag(std::string tag);
    /**
     * Returns true if the given \p tag is present on this GameObject.
    */
    bool HasTag(std::string tag);
private:
    std::unordered_map<ComponentType, ComponentV2*> m_components;
    ApplicationV2* m_application;
    std::string object_name;
    std::vector<std::string> m_tags;
};