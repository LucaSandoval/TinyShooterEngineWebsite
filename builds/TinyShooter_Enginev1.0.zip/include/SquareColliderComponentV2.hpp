#pragma once

#include "ComponentV2.hpp"

class GameObjectV2;

/**
 * SquareColliderComponentV2 is a component for handle simple 2D collisions between squares.
*/
class SquareColliderComponentV2 : public ComponentV2 {
public:
    SquareColliderComponentV2(ApplicationV2* application, GameObjectV2* game_object);
    ~SquareColliderComponentV2();

    virtual void Input(float delta_time);
    virtual void Update(float delta_time);
    virtual void Render();

    virtual ComponentType GetType();
    /**
     * Returns true if the given GameObject \p other is colliding with this SquareColliderComponentV2. The other
     * GameObject does not need a SquareColliderComponentV2 of its own.
    */
    bool CollidedWith(GameObjectV2* other);
};