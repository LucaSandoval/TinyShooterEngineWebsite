#pragma once

#include "ComponentV2.hpp"

/**
 * A component for handling simple movement using velocity.
*/
class MovementComponentV2 : public ComponentV2 {
public:
    MovementComponentV2(ApplicationV2* application, GameObjectV2* game_object);
    ~MovementComponentV2();

    virtual void Input(float delta_time);
    virtual void Update(float delta_time);
    virtual void Render();

    virtual ComponentType GetType();
    /**
     * Sets the \p can_move value of this MovementComponent. The Component will not try to move the GameObject's transform
     * if set to false.
    */
    void SetCanMove(bool can_move);
    /**
     * Sets the X and Y velocity of this MovementComponent.
    */
    void SetVelocity(float xVel, float yVel);
    /**
     * Returns the current X velocity of the MovementComponent.
    */
    float GetXVel();
    /**
     * Returns the current Y velocity of the MovementComponent.
    */
    float GetYVel();
    /**
     * Returns the X position of the GameObject this component is attatched to before the last
     * Update() function was called.
    */
    float GetPreMoveX();
    /**
     * Returns the Y position of the GameObject this component is attatched to before the last
     * Update() function was called.
    */
    float GetPreMoveY();
private:
    bool can_move;
    float xVel, yVel;
    float pre_move_x, pre_move_y;
};