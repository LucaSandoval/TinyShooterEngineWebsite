#pragma once

#include "ComponentV2.hpp"
#include <SDL3/SDL.h>
#include <string>

/**
 * SpriteComponentV2 is a component for rendering a GameObject visibly using a .bmp sprite.
*/
class SpriteComponentV2 : public ComponentV2 {
public:
    SpriteComponentV2(ApplicationV2* application, GameObjectV2* game_object);
    ~SpriteComponentV2();

    virtual void Input(float delta_time);
    virtual void Update(float delta_time);
    virtual void Render();

    virtual ComponentType GetType();

    /**
     * Sets the sprite for this SpriteComponentV2 to the .bmp sprite given at the \p path .
    */
    void SetSprite(std::string path);
    /**
     * Sets the visibility of this sprite. If \p visible is set to false the sprite will not render.
    */
    void SetVisibility(bool visible);
private:
    bool is_visible;
    SDL_Texture* m_texture;
};