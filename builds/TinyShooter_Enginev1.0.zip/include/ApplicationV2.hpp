#pragma once

#include "SDLGraphicsProgramV2.hpp"
#include "SceneV2.hpp"

#include <SDL3/SDL.h>
#include <cstdlib>
#include <vector>
#include <memory>
#include <string>

/**
 * The ApplicationV2 class represents an instance of a TinyShooter Engine application. 
 * Manages SDL to provide a game winodw to use, manages loading and configuring
 * scenes to be loaded and used in the game, and handles input for the game. Provides
 * a public Tick() method to control the passage of each frame in the engine.
*/
class ApplicationV2 {
public:
    /**
     * Constructor for a new TinyShooter Engine application, specifying the
     * \p w : window width and \p h : window height.
    */
    ApplicationV2(int w, int h);
    /**
     * Basic destructor. Will free all memory used in 
     * Scenes, GameObjects, and Components allong with the SDL program. Makes a call to
     * Shutdown().
    */
    ~ApplicationV2();
    /**
     * Calls Input() , Update() , and Render() on the currently loaded scene.
     * \p delta_time is the the real time in seconds between the previous and current call of Tick().
     * You will likely use Tick() in some sort of loop.
    */
    void Tick(float delta_time);
    /**
     * Will free all memory used in 
     * Scenes, GameObjects, and Components allong with the SDL program.
    */
    void Shutdown();
    /**
     * Loads scene with the given \p scene_name, given using the AddScene() method.
    */
    void LoadScene(std::string scene_name);
    /**
     * Adds a SceneV2* \p scene to the current application under the given name \p scene_path .
    */
    void AddScene(SceneV2* scene, std::string scene_name);
    /**
     * Reloads (returns it to its default state) a scene in the application under the given \p scene_name .
    */
    void ReloadScene(std::string scene_name);
    /**
     * Returns a reference to the underlying SDLGraphicsProgramV2* managing the window.
    */
    SDLGraphicsProgramV2* GetGraphicsProgram();
    /**
     * Returns a pointer to the current loaded scene.
    */
    SceneV2* GetCurrentScene();
    /**
     * Returns true if the space key is currently being pressed.
    */
    bool SpaceKeyPressed();
    /**
     * Returns true if the Up Arrow key is currently being pressed.
    */
    bool UpKeyPressed();
    /**
     * Returns true if the Down Arrow key is currently being pressed.
    */
    bool DownKeyPressed();
    /**
     * Returns true if the Right Arrow key is currently being pressed.
    */
    bool RightKeyPressed();
    /**
     * Returns true if the Left Arrow key is currently being pressed.
    */
    bool LeftKeyPressed();
    /**
     * Returns true if the Escape key is currently being pressed.
    */
    bool EscapeKeyPressed();
    /**
     * Returns true if the W key is currently being pressed.
    */
    bool WKeyPressed();
    /**
     * Returns true if the A key is currently being pressed.
    */
    bool AKeyPressed();
    /**
     * Returns true if the S key is currently being pressed.
    */
    bool SKeyPressed();
    /**
     * Returns true if the D key is currently being pressed.
    */
    bool DKeyPressed();
    /**
     * Returns true if the Right Shift key is currently being pressed.
    */
    bool RShiftKeyPressed();
private:
    void Input(float delta_time);
    void Update(float delta_time);
    void Render();
    bool        is_running {true};
    SDLGraphicsProgramV2* m_program;
    SceneV2* current_scene;
    std::unordered_map<std::string, SceneV2*> loaded_scenes;
};