#pragma once

#include <SDL3/SDL.h>

// The glad library helps setup OpenGL extensions.
#include <glad/glad.h>

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <vector>

/**
 * SDLGraphicsProgramV2 is a class that interfaces with SDL, controlling the 
 * game window and related functionality.
*/
class SDLGraphicsProgramV2{
public:
    /**
     * Constructor for a new SDLGraphicsProgramV2 to be used in a TinyShooter Engine application, specifying the
     * \p w : window width and \p h : window height.
    */
    SDLGraphicsProgramV2(int w, int h);
    /**
     * Basic destructor.
    */
    ~SDLGraphicsProgramV2();
    // Setup OpenGL
    bool initGL();
    /**
     * Clears the current screen, removing all rendered shapes and textures.
    */
    void clear();
    /**
     * Flips to a new buffer.
    */
    void flip();
    /**
     * Delays the rendering for a given \p milliseconds .
    */
    void delay(int milliseconds);
    /**
     * Returns a pointer to the underlying SDLWindow. 
    */
    SDL_Window* getSDLWindow();
    /**
     * Returns a pointer to the underlying SDLRenderer. 
    */
    SDL_Renderer* getSDLRenderer();
    /**
     * Returns an integer corresponding a specific key that was pressed.
    */
    int GetKeyPress();

private:
    // Screen dimension constants
    int screenHeight;
    int screenWidth;
    // The window we'll be rendering to
    SDL_Window* gWindow ;
    // Our renderer
    SDL_Renderer* gRenderer;
};