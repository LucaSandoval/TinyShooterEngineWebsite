#pragma once

#include "GameObjectV2.hpp"
#include <vector>
#include <string>
#include <algorithm>

class ApplicationV2;

/**
 * SceneV2 represents a scene in the current TinyShooter Engine application. A Scene
 * is made up of GameObjectV2 instances, which it manages. Scenes may be created fresh
 * or loaded from a file somewhere.
*/
class SceneV2 {
public:
    /**
     * A basic constructor that creates a brand new, empty scene with no GameObjects. Requires
     * a reference to the current \p application this scene is a part of.
    */
    SceneV2(ApplicationV2* application);
    /**
     * A constructor that loads a scene from a file path given by \p config_path . Requires
     * a reference to the current \p application this scene is a part of.
    */
    SceneV2(ApplicationV2* application, std::string config_path);
    /**
     * Basic destructor that handles deallocating all GameObjects in the scene.
    */
    ~SceneV2();
    /**
     * The Input method for this Scene, takes in \p delta_time , 
     * the real time in seconds between the previous and current call of the application's Tick().
     * This will call Input() on all GameObjects in the scene.
    */
    void Input(float delta_time);
    /**
     * The Update method for this Scene, takes in \p delta_time , 
     * the real time in seconds between the previous and current call of the application's Tick().
     * This will call Update() on all GameObjects in the scene.
    */
    void Update(float delta_time);
    /**
     * The Render method for this Scene.
     * This will call Render() on all GameObjects in the scene.
    */
    void Render();
    /**
     * Given a pointer to a GameObjectV2 \p object , adds it to the current scene.
    */
    void AddGameObject(GameObjectV2* object);
    /**
     * Searches the scene for a GameObject with the given \p name and returns the first one it finds. 
    */
    GameObjectV2* FindGameObject(std::string name);
    /**
     * Searches the scene for any GameObject with the given \p name and returns a list of all GameObjects
     * found.
    */
    std::vector<GameObjectV2*> FindAllGameObjectsOfType(std::string name);
    /**
     * Searches the scene for any GameObject with the given \p tag and returns a list of all GameObjects
     * found.
    */
    std::vector<GameObjectV2*> FindAllGameObjectsWithTag(std::string tag);
    /**
     * Given a pointer to a GameObjectV2, if it belongs to this scene, destroys it and removes it from the scene.
    */
    void DestroyGameObject(GameObjectV2* object);
    /**
     * Spawns a GameObject in the scene loaded from a prefab file at the given \p prefab_path .
    */
    GameObjectV2* SpawnPrefab(std::string prefab_path);
    /**
     * Returns the path to the scene file this SceneV2 was loaded from (if any).
    */
    std::string GetScenePath();
    /**
     * Sets the scene path this SceneV2 was loaded from.
    */
    void SetScenePath(std::string path);
private:
    std::vector<GameObjectV2*> scene_objects;
    ApplicationV2* m_application;
    std::string scene_path;
};