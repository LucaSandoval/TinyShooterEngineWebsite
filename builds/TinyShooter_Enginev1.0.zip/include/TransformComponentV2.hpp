#pragma once

#include "ComponentV2.hpp"

class ApplicationV2;

/**
 * TransformComponentV2 is a component that handles the positioning and size of the GameObjectV2 its attatched to.
 * All GameObjectV2 instances have a TransformComponentV2 by default.
*/
class TransformComponentV2 : public ComponentV2 {
public:
    TransformComponentV2(ApplicationV2* application, GameObjectV2* game_object);
    ~TransformComponentV2();

    virtual void Input(float delta_time);
    virtual void Update(float delta_time);
    virtual void Render();

    virtual ComponentType GetType();

    /**
     * Returns the current X position of the GameObjectV2 this is attatched to.
    */
    float GetX();
    /**
     * Returns the current Y position of the GameObjectV2 this is attatched to.
    */
    float GetY();
    /**
     * Sets the current X position of the GameObjectV2 this is attatched to.
    */
    void SetX(float x);
    /**
     * Sets the current Y position of the GameObjectV2 this is attatched to.
    */
    void SetY(float y);
    /**
     * Sets the current X and Y position of the GameObjectV2 this is attatched to.
    */
    void SetPosition(float x, float y);
    /**
     * Moves the GameObjectV2 this is attatched to along the X and Y axis by the given \p x and \p y units.
    */
    void Move(float x, float y);
    /**
     * Retruns the current Width of the GameObjectV2 this is attatched to.
    */
    int GetWidth();
    /**
     * Retruns the current Height of the GameObjectV2 this is attatched to.
    */
    int GetHeight();
    /**
     * Sets the current Width of the GameObjectV2 this is attatched to.
    */
    void SetWidth(int w);
    /**
     * Sets the current Height of the GameObjectV2 this is attatched to.
    */
    void SetHeight(int h);
private:
    float x_pos, y_pos;
    int width, height;
};