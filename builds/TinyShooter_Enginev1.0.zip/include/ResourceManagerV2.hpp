#pragma once

#include <SDL3/SDL.h>
#include <unordered_map>
#include <string>
#include <memory>

/**
 * ResourceManagerV2 is a class for handling resource allocation in TinyShooter Engine, and ensure that assets
 * aren't being loaded uncessarily to improve performance. Currently handles only sprites. 
*/
class ResourceManagerV2 {
public:
    // Static instance
    static ResourceManagerV2& Instance(){
        if(nullptr==m_instance){
            m_instance = new ResourceManagerV2();
        }
        return *m_instance;
    }

    /**
     * Returns a pointer to an SDL_Texture loaded from the given \p filepath . This should be a .bmp
     * sprite file. Additionally requires a reference to the SDL_Renderer being used in the current application.
    */
    SDL_Texture* LoadTexture(SDL_Renderer* renderer, std::string filepath) {
        if (loaded_resources.find(filepath) == loaded_resources.end()) {
            SDL_Surface* pixels = SDL_LoadBMP(filepath.c_str()); 
            SDL_Texture* pTexture = SDL_CreateTextureFromSurface(renderer, pixels);
            loaded_resources[filepath] = pTexture;
        } 
        return loaded_resources[filepath];
    }

private:
    ResourceManagerV2() {}
    inline static ResourceManagerV2* m_instance{nullptr};
    std::unordered_map<std::string, SDL_Texture*> loaded_resources;
};