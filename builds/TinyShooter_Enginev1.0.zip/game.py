import tinyshooterengine
import time, random, math, argparse

# Parse scene input
parser = argparse.ArgumentParser()
parser.add_argument('scene_path', type=str, help="The path to the scene you would like to load.")
args = parser.parse_args()
scene_to_load = args.scene_path

game_width = 800
game_height = 800

# Set up application and scene for testing
application = tinyshooterengine.Application(game_width, game_height)
# "./scenes/test_scene.txt"
scene = tinyshooterengine.Scene(application, scene_to_load)

# Load main scene
application.AddScene(scene, "Main")
application.LoadScene("Main")

# Global references
current_scene = application.GetCurrentScene()
player_obj = current_scene.FindGameObject("Player")
player_collider = player_obj.GetComponent(tinyshooterengine.ComponentType.SquareColliderComponent)
player_transform = player_obj.Transform()

# Create life counter
life_counter = scene.SpawnPrefab("./Assets/prefabs/life_counter.txt")
life_counter_sprite = life_counter.GetComponent(tinyshooterengine.ComponentType.SpriteComponent)

# Create HUD
hud = scene.SpawnPrefab("./Assets/prefabs/hud.txt")
hud.Transform().SetPosition(0, 700)

current_time = time.time()

player_lives = 3
player_move_speed = 200
player_bullet_speed = 400
enemy_move_speed = 100
enemy_bullet_speed = 400

# Gets enemy random movment
def get_enemy_random_movement():
    picks = [random.uniform(0.8, 1), random.uniform(-0.8, -1)]
    rand_x_vel = random.choice(picks)
    rand_y_vel = random.choice(picks)
    return enemy_move_speed * rand_x_vel, enemy_move_speed * rand_y_vel

# Initial enemy movement
scene_enemies = current_scene.FindAllGameObjectsWithTag("Enemy")
for enemy in scene_enemies:
    x, y = get_enemy_random_movement()
    enemy.GetComponent(tinyshooterengine.ComponentType.MovementComponent).SetVelocity(x, y)

shoot_time = 0.6
shoot_timer = shoot_time

enemy_shoot_time = 2
enemy_shoot_timer = enemy_shoot_time

# Fire player bullet
def fire_player_bullet(direction):
    global shoot_timer
    global shoot_time 

    new_bullet = current_scene.SpawnPrefab("./Assets/prefabs/player_bullet.txt")
    new_bullet.Transform().SetPosition(old_player_x, old_player_y)
    if direction == 1:
        bullet_mvmt = new_bullet.GetComponent(tinyshooterengine.ComponentType.MovementComponent).SetVelocity(0, -player_bullet_speed)
    elif direction == 2:
        bullet_mvmt = new_bullet.GetComponent(tinyshooterengine.ComponentType.MovementComponent).SetVelocity(player_bullet_speed, 0)
    elif direction == 3:
        bullet_mvmt = new_bullet.GetComponent(tinyshooterengine.ComponentType.MovementComponent).SetVelocity(0, player_bullet_speed)
    else:
        bullet_mvmt = new_bullet.GetComponent(tinyshooterengine.ComponentType.MovementComponent).SetVelocity(-player_bullet_speed, 0)

    shoot_timer = shoot_time

# Fire enemy bullet
def fire_enemy_bullet(start_x, start_y, player_x, player_y):
    new_enemy_bullet = current_scene.SpawnPrefab("./Assets/prefabs/enemy_bullet.txt")
    new_enemy_bullet.Transform().SetPosition(start_x, start_y)

    x_comp = player_x - start_x
    y_comp = player_y - start_y
    magnitude = math.sqrt((x_comp ** 2) + (y_comp ** 2))
    x_comp = x_comp / magnitude
    y_comp = y_comp / magnitude

    new_enemy_bullet.GetComponent(tinyshooterengine.ComponentType.MovementComponent).SetVelocity(x_comp * enemy_bullet_speed, y_comp * enemy_bullet_speed)


# Game Loop
while True:

    # Calculate delta time
    new_time = time.time()
    delta_time = new_time - current_time
    current_time = new_time

    if shoot_timer > 0:
        shoot_timer -= delta_time

    old_player_x = player_transform.GetX()
    old_player_y = player_transform.GetY()

    # Player moving
    if application.WKeyPressed():
        player_transform.Move(0, -player_move_speed * delta_time)
    if application.SKeyPressed():
        player_transform.Move(0, player_move_speed * delta_time)
    if application.AKeyPressed():
        player_transform.Move(-player_move_speed * delta_time, 0)
    if application.DKeyPressed():
        player_transform.Move(player_move_speed * delta_time, 0)

    # Player bounds check
    if player_transform.GetX() < 0 or player_transform.GetX() > game_width - player_transform.GetWidth():
        player_transform.SetPosition(old_player_x, old_player_y)
    if player_transform.GetY() < 0 or player_transform.GetY() > game_height - player_transform.GetHeight():
        player_transform.SetPosition(old_player_x, old_player_y)

    # Player shooting
    if application.UpKeyPressed() and shoot_timer <= 0:
        fire_player_bullet(1)
    if application.RightKeyPressed() and shoot_timer <= 0:
        fire_player_bullet(2)
    if application.DownKeyPressed() and shoot_timer <= 0:
        fire_player_bullet(3)
    if application.LeftKeyPressed() and shoot_timer <= 0:
        fire_player_bullet(4)

    # Game quit
    if application.EscapeKeyPressed():
        break
    # Check for loss
    if player_lives <= 0:
        print("GAME OVER!")
        break

    scene_player_bullets = current_scene.FindAllGameObjectsOfType("PlayerBullet")
    scene_boxes = current_scene.FindAllGameObjectsOfType("Box")
    scene_enemies = current_scene.FindAllGameObjectsWithTag("Enemy")

    # Check for win
    if len(scene_enemies) == 0:
        print("YOU WIN!")
        break

    # Enemy shooting
    if enemy_shoot_timer > 0:
        enemy_shoot_timer -= delta_time
    else:
        for enemy in scene_enemies:
            fire_enemy_bullet(enemy.Transform().GetX(), enemy.Transform().GetY(), old_player_x, old_player_y)

        enemy_shoot_timer = enemy_shoot_time

    scene_enemy_bullets = current_scene.FindAllGameObjectsOfType("EnemyBullet")

    # Enemy Bullet collisions
    for enemy_bullet in scene_enemy_bullets:
        enemy_bullet_col = enemy_bullet.GetComponent(tinyshooterengine.ComponentType.SquareColliderComponent)
        for box in scene_boxes:
            if enemy_bullet_col.CollidedWith(box):
                current_scene.DestroyGameObject(enemy_bullet)
        if enemy_bullet_col.CollidedWith(player_obj):
            current_scene.DestroyGameObject(enemy_bullet)
            player_lives -= 1
            if (player_lives == 2):
                life_counter_sprite.SetSprite("./Assets/sprites/engines_lives2.bmp")
            else:
                life_counter_sprite.SetSprite("./Assets/sprites/engines_lives3.bmp")

    # Enemy Collisions
    for enemy in scene_enemies:
        enemy_transform = enemy.Transform()
        enemy_mvmt_cmp = enemy.GetComponent(tinyshooterengine.ComponentType.MovementComponent)
        enemy_col = enemy.GetComponent(tinyshooterengine.ComponentType.SquareColliderComponent)
        enemy_prev_x = enemy_mvmt_cmp.GetPreMoveX()
        enemy_prev_y = enemy_mvmt_cmp.GetPreMoveY()
        # Left right bound check
        if enemy_transform.GetX() < 0:
            yVel = enemy_mvmt_cmp.GetYVel()
            xVel = enemy_mvmt_cmp.GetXVel()
            enemy_mvmt_cmp.SetVelocity(-xVel, yVel)
            enemy.Transform().SetPosition(1, enemy_transform.GetY())

        if enemy_transform.GetX() > game_width - enemy_transform.GetWidth():
            yVel = enemy_mvmt_cmp.GetYVel()
            xVel = enemy_mvmt_cmp.GetXVel()
            enemy_mvmt_cmp.SetVelocity(-xVel, yVel)
            enemy.Transform().SetPosition((game_width - enemy_transform.GetWidth()) - 1, enemy_transform.GetY())

        # Top bottom bound check
        if enemy_transform.GetY() < 0:
            yVel = enemy_mvmt_cmp.GetYVel()
            xVel = enemy_mvmt_cmp.GetXVel()
            enemy_mvmt_cmp.SetVelocity(xVel, -yVel)
            enemy.Transform().SetPosition(enemy_transform.GetX(), 1)

        if enemy_transform.GetY() > game_height - enemy_transform.GetHeight():
            yVel = enemy_mvmt_cmp.GetYVel()
            xVel = enemy_mvmt_cmp.GetXVel()
            enemy_mvmt_cmp.SetVelocity(xVel, -yVel)
            enemy.Transform().SetPosition(enemy_transform.GetX(), (game_height - enemy_transform.GetHeight()) - 1)

        # Box collision test
        for box in scene_boxes:
            if enemy_col.CollidedWith(box):
                yVel = enemy_mvmt_cmp.GetYVel()
                xVel = enemy_mvmt_cmp.GetXVel()
                enemy_mvmt_cmp.SetVelocity(-xVel, -yVel)
                enemy.Transform().SetPosition(enemy_prev_x, enemy_prev_y)
        

    # Box Collisions
    for box in scene_boxes:
        if player_collider.CollidedWith(box):
            player_transform.SetPosition(old_player_x, old_player_y)

    # Player bullet collisions
    for player_bullet in scene_player_bullets:
        collider = player_bullet.GetComponent(tinyshooterengine.ComponentType.SquareColliderComponent)
        transform = player_bullet.Transform()
        # Should kill enemies & self
        for enemy in scene_enemies:
            if collider.CollidedWith(enemy):
                if enemy.HasTag("StrongEnemy"):
                    if enemy.HasTag("Wounded"):
                        current_scene.DestroyGameObject(enemy)
                    else:
                        enemy.AddTag("Wounded")
                        enemy.GetComponent(tinyshooterengine.ComponentType.SpriteComponent).SetSprite("./Assets/sprites/engines_strong_enemy2.bmp")
                else:
                    current_scene.DestroyGameObject(enemy)
                current_scene.DestroyGameObject(player_bullet)
        # Should just kill self
        for box in scene_boxes:
            if collider.CollidedWith(box):
                current_scene.DestroyGameObject(player_bullet)
        # Check for out of bounds


    # Tick application
    application.Tick(delta_time)

application.Shutdown()