#include "SDLGraphicsProgramV2.hpp"

// Initialization function
// Returns a true or false value based on successful completion of setup.
// Takes in dimensions of window.
SDLGraphicsProgramV2::SDLGraphicsProgramV2(int w, int h):screenWidth(w),screenHeight(h){
	// Initialization flag
	bool success = true;
	// String to hold any errors that occur.
	std::stringstream errorStream;
	// The window we'll be rendering to
	gWindow = NULL;
	// Render flag

	// Initialize SDL
	if(SDL_Init(SDL_INIT_VIDEO)< 0){
		errorStream << "SDL could not initialize! SDL Error: " << SDL_GetError() << "\n";
		success = false;
	}
	else{
	    //Create window
    	gWindow = SDL_CreateWindow( "TinyShooter Engine 1.0", screenWidth, screenHeight, SDL_WINDOW_OPENGL );

        // Check if Window did not create.
        if( gWindow == NULL ){
			errorStream << "Window could not be created! SDL Error: " << SDL_GetError() << "\n";
			success = false;
		}

		//Create a Renderer to draw on
        gRenderer = SDL_CreateRenderer(gWindow, NULL, SDL_RENDERER_ACCELERATED);
        // Check if Renderer did not create.
        if( gRenderer == NULL ){
            errorStream << "Renderer could not be created! SDL Error: " << SDL_GetError() << "\n";
            success = false;
        }
  	}

    
    
    // If initialization did not work, then print out a list of errors in the constructor.
    if(!success){
        errorStream << "SDLGraphicsProgramV2::SDLGraphicsProgramV2 - Failed to initialize!\n";
        std::string errors=errorStream.str();
        SDL_Log("%s\n",errors.c_str());
    }else{
        SDL_Log("SDLGraphicsProgramV2::SDLGraphicsProgramV2 - No SDL, GLAD, or OpenGL, errors detected during initialization\n\n");
    }

}


// Proper shutdown of SDL and destroy initialized objects
SDLGraphicsProgramV2::~SDLGraphicsProgramV2(){
    //Destroy window
	SDL_DestroyWindow( gWindow );
	// Point gWindow to NULL to ensure it points to nothing.
	gWindow = NULL;
	//Quit SDL subsystems
	SDL_Quit();
}


// Initialize OpenGL
// Setup any of our shaders here.
bool SDLGraphicsProgramV2::initGL(){
	//Success flag
	bool success = true;

	return success;
}


// clear
// Clears the screen
void SDLGraphicsProgramV2::clear(){
	// Nothing yet!
    SDL_SetRenderDrawColor(gRenderer, 0x00, 0x00, 0x00, 0xFF);
    SDL_RenderClear(gRenderer);   
}
// Flip
// The flip function gets called once per loop
// It swaps out the previvous frame in a double-buffering system
void SDLGraphicsProgramV2::flip(){
	// Nothing yet!
    SDL_RenderPresent(gRenderer);
}


void SDLGraphicsProgramV2::delay(int milliseconds){
    SDL_Delay(milliseconds); 
}

int SDLGraphicsProgramV2::GetKeyPress() {
    SDL_Event event;
    SDL_PollEvent(&event);

    const Uint8 *state = SDL_GetKeyboardState(NULL);
    if (state[SDL_SCANCODE_ESCAPE]) {
        return 1;
    }
    if (state[SDL_SCANCODE_UP]) {
        return 2;
    }
    if (state[SDL_SCANCODE_DOWN]) {
        return 3;
    }
    if (state[SDL_SCANCODE_LEFT]) {
        return 4;
    }
    if (state[SDL_SCANCODE_RIGHT]) {
        return 5;
    }
    if (state[SDL_SCANCODE_SPACE]) {
        return 6;
    }
    if (state[SDL_SCANCODE_W]) {
        return 7;
    }
    if (state[SDL_SCANCODE_A]) {
        return 8;
    }
    if (state[SDL_SCANCODE_S]) {
        return 9;
    }
    if (state[SDL_SCANCODE_D]) {
        return 10;
    }
    if (state[SDL_SCANCODE_RSHIFT]) {
        return 11;
    }
    return 0;
}


// Get Pointer to Window
SDL_Window* SDLGraphicsProgramV2::getSDLWindow(){
  return gWindow;
}

SDL_Renderer *SDLGraphicsProgramV2::getSDLRenderer()
{
    return gRenderer;
}