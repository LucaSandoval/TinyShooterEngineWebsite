#include "SceneV2.hpp"
#include "ApplicationV2.hpp"
#include "SpriteComponentV2.hpp"

SceneV2::SceneV2(ApplicationV2* application)
{
    m_application = application;
    scene_path = "";
}

SceneV2::SceneV2(ApplicationV2 *application, std::string config_path)
{
    m_application = application;

    std::ifstream file(config_path);
    if (!file.is_open()) {
        SDL_Log("Unable to find scene file: %s", config_path);
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string token;
        
        while (iss >> token) {
            if (token == "[PREFAB]") {
                iss >> token;
                GameObjectV2* new_obj = SpawnPrefab(token);
                iss >> token;
                int x = std::stoi(token);
                iss >> token;
                int y = std::stoi(token);
                new_obj->Transform()->SetPosition(x, y);
            } else if (token == "#") {
                break;
            }
        }
    }

    //SDL_Log("All prefabs spawend.");

    SetScenePath(config_path);
}

SceneV2::~SceneV2()
{
    for(auto &obj : scene_objects){
        delete(obj);
    }
}

void SceneV2::Input(float delta_time)
{
    for(auto &obj : scene_objects){
        obj->Input(delta_time);
    }
}

void SceneV2::Update(float delta_time)
{
    for(auto &obj : scene_objects){
        obj->Update(delta_time);
    }
}

void SceneV2::Render()
{
    for(auto &obj : scene_objects){
        obj->Render();
    }
}

void SceneV2::AddGameObject(GameObjectV2 *object)
{
    scene_objects.push_back(object);
}

GameObjectV2 *SceneV2::FindGameObject(std::string name)
{
    for(auto &obj : scene_objects){
        if (obj->GetName() == name) {
            return obj;
        }
    }
    return nullptr;
}

std::vector<GameObjectV2 *> SceneV2::FindAllGameObjectsOfType(std::string name)
{
    std::vector<GameObjectV2 *> output;
    for(auto &obj : scene_objects){
        if (obj->GetName() == name) {
            output.push_back(obj);
        }
    }
    return output;
}

std::vector<GameObjectV2 *> SceneV2::FindAllGameObjectsWithTag(std::string tag)
{
    std::vector<GameObjectV2 *> output;
    for(auto &obj : scene_objects){
        if (obj->HasTag(tag)) {
            output.push_back(obj);
        }
    }
    return output;
}

void SceneV2::DestroyGameObject(GameObjectV2 *object)
{
    auto itr = std::find(scene_objects.begin(), scene_objects.end(), object);
    if (itr != scene_objects.end()) {
        delete *itr;
        scene_objects.erase(itr);
    }
}

GameObjectV2* SceneV2::SpawnPrefab(std::string prefab_path)
{
    std::ifstream file(prefab_path);
    if (!file.is_open()) {
        SDL_Log("Unable to find prefab file: %s", prefab_path);
        return nullptr;
    }

    // Create new game object, and parse file to add/get information
    GameObjectV2* new_obj = new GameObjectV2(m_application);

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string token;
        
        while (iss >> token) {
            if (token == "[NAME]") {
                iss >> token;
                new_obj->SetName(token);
            } else if (token == "[SIZE]") {
                iss >> token;
                new_obj->Transform()->SetWidth(std::stoi(token));
                iss >> token;
                new_obj->Transform()->SetHeight(std::stoi(token));
            } else if (token == "[COMPONENT]") {
                iss >> token;
                if (token == "SpriteComponent") {
                    new_obj->AddComponent(ComponentType::SpriteComponent);
                } else if (token == "SquareColliderComponent") {
                    new_obj->AddComponent(ComponentType::SquareColliderComponent);
                } else if (token == "MovementComponent") {
                    new_obj->AddComponent(ComponentType::MovementComponent);
                } else {
                    SDL_Log("Unable to find component: %s", token);
                }
            } else if (token == "[SPRITE]") {
                SpriteComponentV2* comp = (SpriteComponentV2*)new_obj->GetComponent(ComponentType::SpriteComponent);
                if (comp != nullptr) {
                    iss >> token;
                    comp->SetSprite(token);
                }
            } else if (token == "[TAG]") {
                iss >> token;
                new_obj->AddTag(token);
            }
        }
    }

    AddGameObject(new_obj);
    return new_obj;
}

std::string SceneV2::GetScenePath()
{
    return scene_path;
}

void SceneV2::SetScenePath(std::string path)
{
    scene_path = path;
}
