#include "SquareColliderComponentV2.hpp"
#include "ApplicationV2.hpp"
#include "GameObjectV2.hpp"

SquareColliderComponentV2::SquareColliderComponentV2(ApplicationV2 *application, GameObjectV2 *game_object) : ComponentV2(application, game_object)
{
}

SquareColliderComponentV2::~SquareColliderComponentV2()
{
}

void SquareColliderComponentV2::Input(float delta_time)
{
}

void SquareColliderComponentV2::Update(float delta_time)
{
}

void SquareColliderComponentV2::Render()
{
}

ComponentType SquareColliderComponentV2::GetType()
{
    return ComponentType::SquareColliderComponent;
}

bool SquareColliderComponentV2::CollidedWith(GameObjectV2 *other)
{
    if (other != nullptr) {
        if (GetGameObject() != nullptr) {
            if (GetGameObject()->Transform() != nullptr) {
                if (other->Transform() != nullptr) {
                    int other_x = other->Transform()->GetX();
                    int other_y = other->Transform()->GetY();
                    int other_w = other->Transform()->GetWidth();
                    int other_h = other->Transform()->GetHeight();
                    int my_x = GetGameObject()->Transform()->GetX();
                    int my_y = GetGameObject()->Transform()->GetY();
                    int my_w = GetGameObject()->Transform()->GetWidth();
                    int my_h = GetGameObject()->Transform()->GetHeight();

                    bool x_col = (my_x < other_x + other_w) && (my_x + my_w > other_x);
                    bool y_col = (my_y < other_y + other_h) && (my_y + my_h > other_y);
                    return x_col && y_col;
                }
            }
        }
    }

    return false;
}
