// Files to include in binding
//#include "test.hpp"
#include "SDLGraphicsProgramV2.hpp"
#include "ApplicationV2.hpp"
#include "GameObjectV2.hpp"
#include "ComponentV2.hpp"
#include "TransformComponentV2.hpp"
#include "SpriteComponentV2.hpp"
#include "SquareColliderComponentV2.hpp"
#include "MovementComponentV2.hpp"
// Include the pybindings
#include <pybind11/pybind11.h>

namespace py = pybind11;

PYBIND11_MODULE(tinyshooterengine, m){
    m.doc() = "The TinyShooter Engine."; // Optional docstring

    py::class_<ApplicationV2>(m, "Application")
            .def(py::init<int, int>(), py::arg("w"), py::arg("h"), py::return_value_policy::reference_internal)
            .def("LoadScene", &ApplicationV2::LoadScene)
            .def("AddScene", &ApplicationV2::AddScene)
            .def("Shutdown", &ApplicationV2::Shutdown)
            .def("GetCurrentScene", &ApplicationV2::GetCurrentScene, py::return_value_policy::reference)
            .def("Tick", &ApplicationV2::Tick)
            .def("SpaceKeyPressed", &ApplicationV2::SpaceKeyPressed)
            .def("UpKeyPressed", &ApplicationV2::UpKeyPressed)
            .def("DownKeyPressed", &ApplicationV2::DownKeyPressed)
            .def("RightKeyPressed", &ApplicationV2::RightKeyPressed)
            .def("LeftKeyPressed", &ApplicationV2::LeftKeyPressed)
            .def("EscapeKeyPressed", &ApplicationV2::EscapeKeyPressed)
            .def("WKeyPressed", &ApplicationV2::WKeyPressed)
            .def("AKeyPressed", &ApplicationV2::AKeyPressed)
            .def("SKeyPressed", &ApplicationV2::SKeyPressed)
            .def("DKeyPressed", &ApplicationV2::DKeyPressed)
            .def("RShiftKeyPressed", &ApplicationV2::RShiftKeyPressed);

    py::class_<GameObjectV2>(m, "GameObject")
            .def(py::init<ApplicationV2*>(), py::arg("application"), py::return_value_policy::reference)
            .def("AddComponent", &GameObjectV2::AddComponent)
            .def("GetComponent", &GameObjectV2::GetComponent, py::return_value_policy::reference)
            .def("Transform", &GameObjectV2::Transform, py::return_value_policy::reference)
            .def("SetName", &GameObjectV2::SetName)
            .def("GetName", &GameObjectV2::GetName)
            .def("AddTag", &GameObjectV2::AddTag)
            .def("HasTag", &GameObjectV2::HasTag);

    py::class_<TransformComponentV2>(m, "TransformComponent")
            .def(py::init<ApplicationV2*, GameObjectV2*>(), py::arg("application"), py::arg("game_object"), py::return_value_policy::reference)
            .def("GetType", &TransformComponentV2::GetType)
            .def("GetX", &TransformComponentV2::GetX)
            .def("GetY", &TransformComponentV2::GetY)
            .def("SetX", &TransformComponentV2::SetX)
            .def("SetY", &TransformComponentV2::SetY)
            .def("SetPosition", &TransformComponentV2::SetPosition)
            .def("Move", &TransformComponentV2::Move)
            .def("GetWidth", &TransformComponentV2::GetWidth)
            .def("GetHeight", &TransformComponentV2::GetHeight)
            .def("SetHeight", &TransformComponentV2::SetHeight)
            .def("SetWidth", &TransformComponentV2::SetWidth);

    py::class_<SpriteComponentV2>(m, "SpriteComponent")
            .def(py::init<ApplicationV2*, GameObjectV2*>(), py::arg("application"), py::arg("game_object"), py::return_value_policy::reference)
            .def("SetSprite", &SpriteComponentV2::SetSprite)
            .def("SetVisibility", &SpriteComponentV2::SetVisibility);

    py::class_<SquareColliderComponentV2>(m, "SquareColliderComponent")
            .def(py::init<ApplicationV2*, GameObjectV2*>(), py::arg("application"), py::arg("game_object"), py::return_value_policy::reference)
            .def("CollidedWith", &SquareColliderComponentV2::CollidedWith);

    py::class_<MovementComponentV2>(m, "MovementComponent")
            .def(py::init<ApplicationV2*, GameObjectV2*>(), py::arg("application"), py::arg("game_object"), py::return_value_policy::reference)
            .def("SetCanMove", &MovementComponentV2::SetCanMove)
            .def("SetVelocity", &MovementComponentV2::SetVelocity)
            .def("GetXVel", &MovementComponentV2::GetXVel)
            .def("GetYVel", &MovementComponentV2::GetYVel)
            .def("GetPreMoveX", &MovementComponentV2::GetPreMoveX)
            .def("GetPreMoveY", &MovementComponentV2::GetPreMoveY);

    py::enum_<ComponentType>(m, "ComponentType")
            .value("TransformComponent", ComponentType::TransformComponent)
            .value("SpriteComponent", ComponentType::SpriteComponent)
            .value("SquareColliderComponent", ComponentType::SquareColliderComponent)
            .value("MovementComponent", ComponentType::MovementComponent);

    py::class_<SceneV2>(m, "Scene")
            .def(py::init<ApplicationV2*>(), py::arg("application"), py::return_value_policy::reference)
            .def(py::init<ApplicationV2*, std::string>(), py::arg("application"), py::arg("config_path"), py::return_value_policy::reference)
            .def("AddGameObject", &SceneV2::AddGameObject)
            .def("SpawnPrefab", &SceneV2::SpawnPrefab, py::return_value_policy::reference)
            .def("FindGameObject", &SceneV2::FindGameObject, py::return_value_policy::reference)
            .def("DestroyGameObject", &SceneV2::DestroyGameObject)
            .def("FindAllGameObjectsOfType", [](SceneV2 &scene, const std::string type) {
            std::vector<GameObjectV2*> gameObjects = scene.FindAllGameObjectsOfType(type);
            py::list pyList;
            for (GameObjectV2* obj : gameObjects) {
                pyList.append(obj);
            }
            return pyList;
            })
            .def("FindAllGameObjectsWithTag", [](SceneV2 &scene, const std::string tag) {
            std::vector<GameObjectV2*> gameObjects = scene.FindAllGameObjectsWithTag(tag);
            py::list pyList;
            for (GameObjectV2* obj : gameObjects) {
                pyList.append(obj);
            }
            return pyList;
            });
}