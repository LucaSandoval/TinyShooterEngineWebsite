#include "ApplicationV2.hpp"

ApplicationV2::ApplicationV2(int w, int h)
{
    m_program = new SDLGraphicsProgramV2(w, h);
}

ApplicationV2::~ApplicationV2()
{
    Shutdown();
}

void ApplicationV2::Tick(float delta_time)
{
    Input(delta_time);
    Update(delta_time);
    Render();
}

void ApplicationV2::Shutdown()
{
    delete(m_program);
    for(auto &scene : loaded_scenes) {
        delete(scene.second);
    }
}

void ApplicationV2::Input(float delta_time)
{
    if (m_program != nullptr && current_scene != nullptr) {
        current_scene->Input(delta_time);
    }
}

void ApplicationV2::Update(float delta_time)
{
    if (m_program != nullptr && current_scene != nullptr) {
        current_scene->Update(delta_time);
    }
}

void ApplicationV2::Render()
{
    if (m_program != nullptr && current_scene != nullptr) {
        m_program->clear();
        current_scene->Render();
        m_program->flip();
    }
}

void ApplicationV2::LoadScene(std::string scene_name)
{
    if (loaded_scenes.find(scene_name) != loaded_scenes.end()) {
        current_scene = loaded_scenes[scene_name];
    } else {
        SDL_Log("No scene found!");
    }
}

void ApplicationV2::AddScene(SceneV2* scene, std::string scene_name)
{
    loaded_scenes[scene_name] = scene;
}

void ApplicationV2::ReloadScene(std::string scene_name)
{
    if (loaded_scenes.find(scene_name) != loaded_scenes.end()) {
        std::string scene_path = loaded_scenes[scene_name]->GetScenePath();
        delete(loaded_scenes[scene_name]);
        SceneV2* new_scene = new SceneV2(this, scene_path);
        loaded_scenes[scene_name] = new_scene;
        LoadScene(scene_name);
    } else {
        SDL_Log("No scene found!");
    }
}

SDLGraphicsProgramV2 *ApplicationV2::GetGraphicsProgram()
{
    return m_program;
}

SceneV2 *ApplicationV2::GetCurrentScene()
{
    return current_scene;
}

bool ApplicationV2::SpaceKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 6;
    } else {
        return false;
    }
}

bool ApplicationV2::UpKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 2;
    } else {
        return false;
    }
}

bool ApplicationV2::DownKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 3;
    } else {
        return false;
    }
}

bool ApplicationV2::RightKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 5;
    } else {
        return false;
    }
}

bool ApplicationV2::LeftKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 4;
    } else {
        return false;
    }
}

bool ApplicationV2::EscapeKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 1;
    } else {
        return false;
    }
}

bool ApplicationV2::WKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 7;
    } else {
        return false;
    }
}

bool ApplicationV2::AKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 8;
    } else {
        return false;
    }
}

bool ApplicationV2::SKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 9;
    } else {
        return false;
    }
}

bool ApplicationV2::DKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 10;
    } else {
        return false;
    }
}

bool ApplicationV2::RShiftKeyPressed()
{
    if (m_program != nullptr) {
        return m_program->GetKeyPress() == 11;
    } else {
        return false;
    }
}
