#include "MovementComponentV2.hpp"
#include "TransformComponentV2.hpp"
#include "GameObjectV2.hpp"

MovementComponentV2::MovementComponentV2(ApplicationV2 *application, GameObjectV2 *game_object) : ComponentV2(application, game_object)
{
    can_move = true;
    xVel = 0;
    yVel = 0;
}

MovementComponentV2::~MovementComponentV2()
{
}

void MovementComponentV2::Input(float delta_time)
{
}

void MovementComponentV2::Update(float delta_time)
{
    if (can_move && GetGameObject() != nullptr) {
        TransformComponentV2* transform = GetGameObject()->Transform();
        pre_move_x = transform->GetX();
        pre_move_y = transform->GetY();
        transform->Move((xVel * delta_time), (yVel * delta_time));
    }
}

void MovementComponentV2::Render()
{
}

ComponentType MovementComponentV2::GetType()
{
    return ComponentType::MovementComponent;
}

void MovementComponentV2::SetCanMove(bool can_move)
{
    this->can_move = can_move;
}

void MovementComponentV2::SetVelocity(float xVel, float yVel)
{
    this->xVel = xVel;
    this->yVel = yVel;
}

float MovementComponentV2::GetXVel()
{
    return xVel;
}

float MovementComponentV2::GetYVel()
{
    return yVel;
}

float MovementComponentV2::GetPreMoveX()
{
    return pre_move_x;
}

float MovementComponentV2::GetPreMoveY()
{
    return pre_move_y;
}
