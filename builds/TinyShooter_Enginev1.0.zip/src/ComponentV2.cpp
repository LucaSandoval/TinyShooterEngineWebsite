#include "ComponentV2.hpp"
#include "ApplicationV2.hpp"
#include "GameObjectV2.hpp"

ComponentV2::ComponentV2(ApplicationV2* application, GameObjectV2* game_object)
{
    m_application = application;
    m_game_object = game_object;
}

ComponentV2::~ComponentV2()
{
}

ApplicationV2 *ComponentV2::GetApplication()
{
    // if (m_application == nullptr) {
    //     SDL_Log("WTF1");
    // } else {
    //     SDL_Log("WTF2");
    // }
    return m_application;
}

GameObjectV2 *ComponentV2::GetGameObject()
{
    return m_game_object;
}

// ComponentType ComponentV2::GetType()
// {
//     return ComponentType::SpriteComponent;
// }
