#include "ApplicationV2.hpp"
#include "GameObjectV2.hpp"

GameObjectV2::GameObjectV2(ApplicationV2* application) {
    m_application = application;
    AddComponent(ComponentType::TransformComponent);
}

GameObjectV2::~GameObjectV2() {
    for(auto &pair : m_components) {
        delete(pair.second);
    }
}

void GameObjectV2::Input(float delta_time)
{
    for(auto &pair : m_components) {
        pair.second->Input(delta_time);
    }
}

void GameObjectV2::Update(float delta_time)
{
    for(auto &pair : m_components) {
        pair.second->Update(delta_time);
    }
}

void GameObjectV2::Render()
{
    for(auto &pair : m_components) {
        pair.second->Render();
    }
}

void GameObjectV2::AddComponent(ComponentType type)
{
    if (type == ComponentType::TransformComponent) {
        m_components[type] = new TransformComponentV2(m_application, this);
    } else if (type == ComponentType::SpriteComponent) {
        m_components[type] = new SpriteComponentV2(m_application, this);
    } else if (type == ComponentType::SquareColliderComponent) {
        m_components[type] = new SquareColliderComponentV2(m_application, this);
    } else if (type == ComponentType::MovementComponent) {
        m_components[type] = new MovementComponentV2(m_application, this);
    }
}

ComponentV2 *GameObjectV2::GetComponent(ComponentType type)
{
    auto component = m_components.find(type);
    if (component != m_components.end()) {
        return m_components[type];
    } else {
        return nullptr;
    }
}

TransformComponentV2 *GameObjectV2::Transform()
{
    return (TransformComponentV2*)GetComponent(ComponentType::TransformComponent);
}

void GameObjectV2::SetName(std::string name)
{
    object_name = name;
}

std::string GameObjectV2::GetName()
{
    return object_name;
}

void GameObjectV2::AddTag(std::string tag)
{
    m_tags.push_back(tag);
}

bool GameObjectV2::HasTag(std::string tag)
{
    for(auto m_tag : m_tags){
        if (m_tag == tag) {
            return true;
        }
    }
    return false;
}
