#include "TransformComponentV2.hpp"
#include "ApplicationV2.hpp"

TransformComponentV2::TransformComponentV2(ApplicationV2* application, GameObjectV2* game_object) : ComponentV2(application, game_object)
{
    x_pos = 0;
    y_pos = 0;
    width = 0;
    height = 0;
}

TransformComponentV2::~TransformComponentV2()
{
}

void TransformComponentV2::Input(float delta_time)
{
}

void TransformComponentV2::Update(float delta_time)
{
}

void TransformComponentV2::Render()
{
}

ComponentType TransformComponentV2::GetType()
{
    return ComponentType::TransformComponent;
}

float TransformComponentV2::GetX()
{
    return x_pos;
}

float TransformComponentV2::GetY()
{
    return y_pos;
}

void TransformComponentV2::SetX(float x)
{
    x_pos = x;
}

void TransformComponentV2::SetY(float y)
{
    y_pos = y;
}

void TransformComponentV2::SetPosition(float x, float y)
{
    SetX(x);
    SetY(y);
}

void TransformComponentV2::Move(float x, float y)
{
    SetPosition(GetX() + x, GetY() + y);
}

int TransformComponentV2::GetWidth()
{
    return width;
}

int TransformComponentV2::GetHeight()
{
    return height;
}

void TransformComponentV2::SetWidth(int w)
{
    width = w;
}

void TransformComponentV2::SetHeight(int h)
{
    height = h;
}
