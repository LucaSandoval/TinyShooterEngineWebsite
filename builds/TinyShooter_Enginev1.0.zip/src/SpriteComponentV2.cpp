#include "SpriteComponentV2.hpp"
#include "ApplicationV2.hpp"
#include "GameObjectV2.hpp"
#include "ResourceManagerV2.hpp"

SpriteComponentV2::SpriteComponentV2(ApplicationV2 *application, GameObjectV2* game_object) : ComponentV2(application, game_object)
{
    is_visible = true;
}

SpriteComponentV2::~SpriteComponentV2()
{
}

void SpriteComponentV2::Input(float delta_time)
{
}

void SpriteComponentV2::Update(float delta_time)
{
}

void SpriteComponentV2::Render()
{
    if (is_visible) {
        TransformComponentV2* transform = GetGameObject()->Transform();
        SDL_Renderer* ren = GetApplication()->GetGraphicsProgram()->getSDLRenderer();

        if (transform != nullptr && ren != nullptr) {
            //SDL_Log("Test4");
            SDL_FRect fillRect = {(float)transform->GetX(),(float)transform->GetY(),(float)transform->GetWidth(),(float)transform->GetHeight()};
            if (m_texture != nullptr) {
                //SDL_Log("Test5: %s", GetGameObject()->GetName().c_str());
                SDL_RenderTexture(ren, m_texture, nullptr, &fillRect);
            } else {
                //SDL_Log("Test6");
                SDL_SetRenderDrawColor(ren, 0xFF, 0xFF, 0xFF, 0xFF);
                SDL_RenderFillRect(ren, &fillRect); 
            }
        }
    }
}

ComponentType SpriteComponentV2::GetType()
{
    return ComponentType::SpriteComponent;
}

void SpriteComponentV2::SetSprite(std::string path)
{
    //SDL_Log("Test1");
    ApplicationV2* app = GetApplication();
    //SDL_Log("Test1a");
    SDLGraphicsProgramV2* graph = app->GetGraphicsProgram();
    //SDL_Log("Test1b");
    SDL_Renderer* ren = graph->getSDLRenderer();
    //SDL_Log("Test2");
    m_texture = ResourceManagerV2::Instance().LoadTexture(ren, path);
}

void SpriteComponentV2::SetVisibility(bool visible)
{
    is_visible = visible;
}
