var class_transform_component_v2 =
[
    [ "GetHeight", "class_transform_component_v2.html#a15fce484a41c6cc9b839682184bf1a45", null ],
    [ "GetType", "class_transform_component_v2.html#a45ab4658731d765a75eaaf63c967aaa0", null ],
    [ "GetWidth", "class_transform_component_v2.html#a7ef5d0b20b4bde956e64c36e955aee4d", null ],
    [ "GetX", "class_transform_component_v2.html#addcc67a283a0acd1f0d6b2aa854c10cf", null ],
    [ "GetY", "class_transform_component_v2.html#a4d451cf3d8b1940f0a4a7f8f0df48d67", null ],
    [ "Input", "class_transform_component_v2.html#a495fd7e9aee4c2365483787574606693", null ],
    [ "Move", "class_transform_component_v2.html#a5dd32354b97af67cc8d04864f3bbb2be", null ],
    [ "Render", "class_transform_component_v2.html#abf48a90dd1025ac7733233b87111a98c", null ],
    [ "SetHeight", "class_transform_component_v2.html#aa5f24327d6f1247c900f900078c682f5", null ],
    [ "SetPosition", "class_transform_component_v2.html#ac837f2ddd20f9933eacc8ba8fa9757ff", null ],
    [ "SetWidth", "class_transform_component_v2.html#a8f9588a1fb266cdeb268d1b525f481b8", null ],
    [ "SetX", "class_transform_component_v2.html#a3be988b477813b5f5520cf267d53bf91", null ],
    [ "SetY", "class_transform_component_v2.html#af788501ae7a868162738cdf342b76e0c", null ],
    [ "Update", "class_transform_component_v2.html#a2d8c0dedbf836b8af82c27b92a982571", null ]
];