var class_game_object_v2 =
[
    [ "GameObjectV2", "class_game_object_v2.html#a25954bf199c40ee9a9d9fde2a5ff1fd2", null ],
    [ "~GameObjectV2", "class_game_object_v2.html#ace958d50db2dfaaccb56409e45980408", null ],
    [ "AddComponent", "class_game_object_v2.html#a762a59b892b32db7918b266043d39b52", null ],
    [ "AddTag", "class_game_object_v2.html#a791d92793cfdff8e1ad8ea5e6b872f6d", null ],
    [ "GetComponent", "class_game_object_v2.html#a772673e950a6d6fed87cc3da591820db", null ],
    [ "GetName", "class_game_object_v2.html#a52742cc091958580e45f3a09d6c06e37", null ],
    [ "HasTag", "class_game_object_v2.html#a4e07cc2e4050c1da1bbd4e42ac9ba06b", null ],
    [ "Input", "class_game_object_v2.html#add813e38d00ebfffb7d0bb6352f7b08d", null ],
    [ "Render", "class_game_object_v2.html#a47b80499418187eb11a344f1a3c00243", null ],
    [ "SetName", "class_game_object_v2.html#a34d48240dfb2ee487091cd79c2d62a0d", null ],
    [ "Transform", "class_game_object_v2.html#a51ea4195ccd587937a9d4a2684870c60", null ],
    [ "Update", "class_game_object_v2.html#a35f20387c7a5c8c69c031eddf278a558", null ]
];