var class_sprite_component_v2 =
[
    [ "GetType", "class_sprite_component_v2.html#a3ab4ef959a20638afca0ff9df74a3b1a", null ],
    [ "Input", "class_sprite_component_v2.html#a5d5604edce6adaf92a3e01092c41ffb8", null ],
    [ "Render", "class_sprite_component_v2.html#a6ef619075dd55472b98894e16b943c95", null ],
    [ "SetSprite", "class_sprite_component_v2.html#aa09e8981387bee35b54097a1c2d48570", null ],
    [ "SetVisibility", "class_sprite_component_v2.html#a75905d9c7b0f9c12c7a35f0c55806475", null ],
    [ "Update", "class_sprite_component_v2.html#a4ecbe2204e13c89960f190d824564298", null ]
];