var searchData=
[
  ['new_5fobj_0',['new_obj',['../namespaceleveleditor.html#a65a956840398b9fc217ce186733419e2',1,'leveleditor']]],
  ['new_5ftile_1',['new_tile',['../namespaceleveleditor.html#a74a3d0469ac99a0b2a4ba99556c766d6',1,'leveleditor']]],
  ['new_5ftime_2',['new_time',['../namespacegame.html#ac251e40a2ca665312fabf1a886507fe7',1,'game.new_time'],['../namespaceleveleditor.html#ac59ab20c588cac4fbf82ab97e8ad20e5',1,'leveleditor.new_time']]]
];
