var searchData=
[
  ['y_0',['y',['../glad_8h.html#a66ddd433d2cacfe27f5906b7e86faeed',1,'y:&#160;glad.h'],['../namespacegame.html#a1894a53da4370d70e444c5e7df8277f2',1,'game.y']]],
  ['y1_1',['y1',['../glad_8h.html#a48340161068d267815ac3131e9d03def',1,'glad.h']]],
  ['y2_2',['y2',['../glad_8h.html#af7158b5d27f7a6aa4ab9973fcc3a5c20',1,'glad.h']]],
  ['yfactor_3',['yfactor',['../glad_8h.html#a35c8ad7bbcca23e97ab9dadfbda4c0c9',1,'glad.h']]],
  ['ymove_4',['ymove',['../glad_8h.html#ac69eb3ea93058abe33dbca40a84234ed',1,'glad.h']]],
  ['yoffset_5',['yoffset',['../glad_8h.html#a76dfb6803dcff61037ba688b7f4242b8',1,'glad.h']]],
  ['yorig_6',['yorig',['../glad_8h.html#a12efb8d14365059e7a8c24a87440d5d7',1,'glad.h']]],
  ['yvel_7',['yVel',['../namespacegame.html#a26fb1be542db4259a4783804957b78a2',1,'game']]]
];
