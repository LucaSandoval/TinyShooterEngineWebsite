var searchData=
[
  ['tile_5fx_0',['tile_x',['../namespaceleveleditor.html#af6aad4aef50ed6705ca7d2bb2bda5196',1,'leveleditor']]],
  ['tile_5fy_1',['tile_y',['../namespaceleveleditor.html#ae3b82a7a77e41308f323a8f90caa0e27',1,'leveleditor']]],
  ['to_5fdelete_2',['to_delete',['../namespaceleveleditor.html#a33ab59a3a28ed8c656673f161e03b143',1,'leveleditor']]],
  ['transform_3',['transform',['../namespacegame.html#ac4fca197effba0af91053fc208cc0031',1,'game']]],
  ['type_4',['type',['../namespacegame.html#adae3fac5c8beeeeec622154d09a70461',1,'game']]]
];
