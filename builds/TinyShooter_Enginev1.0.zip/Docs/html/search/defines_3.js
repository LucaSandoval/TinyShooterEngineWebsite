var searchData=
[
  ['khronos_5fapiattributes_0',['KHRONOS_APIATTRIBUTES',['../khrplatform_8h.html#afd38e339bdb8f65b1ac0c8f214c427e5',1,'khrplatform.h']]],
  ['khronos_5fapicall_1',['KHRONOS_APICALL',['../khrplatform_8h.html#a5d0e04fe11e69b75470eb0a2a2546af3',1,'khrplatform.h']]],
  ['khronos_5fapientry_2',['KHRONOS_APIENTRY',['../khrplatform_8h.html#aff6bea8ea37be81840add529306b32a8',1,'khrplatform.h']]],
  ['khronos_5fmax_5fenum_3',['KHRONOS_MAX_ENUM',['../khrplatform_8h.html#af23931754c6a5adf1892efe8933bf788',1,'khrplatform.h']]],
  ['khronos_5fsupport_5ffloat_4',['KHRONOS_SUPPORT_FLOAT',['../khrplatform_8h.html#a2005a9aed8272da688b4f4ea414531bc',1,'khrplatform.h']]],
  ['khronos_5fsupport_5fint64_5',['KHRONOS_SUPPORT_INT64',['../khrplatform_8h.html#a5000aa7e3c9ca9d348b1d17326a35635',1,'khrplatform.h']]]
];
