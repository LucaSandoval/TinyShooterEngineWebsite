var searchData=
[
  ['major_0',['major',['../structglad_g_lversion_struct.html#ac7f9db11d2679df12ef0313b728554db',1,'gladGLversionStruct']]],
  ['minor_1',['minor',['../structglad_g_lversion_struct.html#acc2bff1c8966c6866f2ad6f5a4e475b2',1,'gladGLversionStruct']]],
  ['move_5ftime_2',['move_time',['../namespaceleveleditor.html#a11cd84a3b2f067260635c5c565a1af37',1,'leveleditor']]],
  ['move_5ftimer_3',['move_timer',['../namespaceleveleditor.html#a327386187a2aadfce8e39c40bb1df3cf',1,'leveleditor']]]
];
