var searchData=
[
  ['x_0',['x',['../namespacegame.html#ab40d16c354eb8514db50c2317b7599e4',1,'game']]],
  ['xvel_1',['xVel',['../namespacegame.html#a4119e96eac3f65dd7e1c60ee7fc984eb',1,'game']]]
];
