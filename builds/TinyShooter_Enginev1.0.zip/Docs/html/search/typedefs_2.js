var searchData=
[
  ['clamp_0',['clamp',['../glad_8h.html#a3878d3005eeb2d2ef414abc752ba3c9b',1,'glad.h']]],
  ['color_1',['color',['../glad_8h.html#a69995a929d818b8b467d4593c24d98bc',1,'glad.h']]],
  ['colornumber_2',['colorNumber',['../glad_8h.html#aa0cc7c98d48d41e532115fa975a55d8e',1,'glad.h']]],
  ['coords_3',['coords',['../glad_8h.html#acdbd39c05bd58b1a6ce737d0189ee608',1,'glad.h']]],
  ['count_4',['count',['../glad_8h.html#a83e2dd3e98558b907ab7fb03cee26bda',1,'glad.h']]]
];
