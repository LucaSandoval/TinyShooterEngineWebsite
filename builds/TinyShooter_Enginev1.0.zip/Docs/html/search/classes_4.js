var searchData=
[
  ['resourcemanagerv2_0',['ResourceManagerV2',['../class_resource_manager_v2.html',1,'']]]
];
