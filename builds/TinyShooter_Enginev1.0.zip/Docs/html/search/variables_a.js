var searchData=
[
  ['old_5fplayer_5fx_0',['old_player_x',['../namespacegame.html#ae953813596c0eeddba3a25a7a5a9b414',1,'game']]],
  ['old_5fplayer_5fy_1',['old_player_y',['../namespacegame.html#a333179b0194110350f5546b92cde6db2',1,'game']]]
];
