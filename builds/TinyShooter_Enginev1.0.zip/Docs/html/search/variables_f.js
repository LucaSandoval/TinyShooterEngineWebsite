var searchData=
[
  ['y_0',['y',['../namespacegame.html#a1894a53da4370d70e444c5e7df8277f2',1,'game']]],
  ['yvel_1',['yVel',['../namespacegame.html#a26fb1be542db4259a4783804957b78a2',1,'game']]]
];
