var searchData=
[
  ['enemy_5fbullet_5fcol_0',['enemy_bullet_col',['../namespacegame.html#a5c54c819b964b2efede31b1c0fd85a40',1,'game']]],
  ['enemy_5fbullet_5fspeed_1',['enemy_bullet_speed',['../namespacegame.html#abd92b9e116b0dc45f5d2ba22c651a9ff',1,'game']]],
  ['enemy_5fcol_2',['enemy_col',['../namespacegame.html#ad2603c5e1185f6bdbb5496f7a98a16fc',1,'game']]],
  ['enemy_5fmove_5fspeed_3',['enemy_move_speed',['../namespacegame.html#a545b9a82e90501cfec65f5ce9ddd7174',1,'game']]],
  ['enemy_5fmvmt_5fcmp_4',['enemy_mvmt_cmp',['../namespacegame.html#a524b3f829d176e3c130d46130d04dee5',1,'game']]],
  ['enemy_5fprev_5fx_5',['enemy_prev_x',['../namespacegame.html#a62edc85aaa0b8a9ecfd98cbeb5d23100',1,'game']]],
  ['enemy_5fprev_5fy_6',['enemy_prev_y',['../namespacegame.html#a34e38a4bdd882b397afea3b22aa3a129',1,'game']]],
  ['enemy_5fshoot_5ftime_7',['enemy_shoot_time',['../namespacegame.html#a64d6ffe40bb92241e25d45d779622752',1,'game']]],
  ['enemy_5fshoot_5ftimer_8',['enemy_shoot_timer',['../namespacegame.html#a0089ef0caa15f377727d05b228ae2b0f',1,'game']]],
  ['enemy_5ftransform_9',['enemy_transform',['../namespacegame.html#ac86facf8a303f7b14e002bd57df7177f',1,'game']]]
];
