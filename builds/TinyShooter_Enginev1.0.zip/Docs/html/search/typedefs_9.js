var searchData=
[
  ['j_0',['j',['../glad_8h.html#a1fb4b4dc7b41b62604a44f280bccbd54',1,'glad.h']]],
  ['j1_1',['j1',['../glad_8h.html#ad542017f1283aa71acb968605407f674',1,'glad.h']]],
  ['j2_2',['j2',['../glad_8h.html#a7b90ba682e4c88c434f5f2a591eb856b',1,'glad.h']]]
];
