var searchData=
[
  ['u1_0',['u1',['../glad_8h.html#ab296853c9d55bfdc62cda6c50d1b4781',1,'glad.h']]],
  ['u2_1',['u2',['../glad_8h.html#a1c6bf6fa786a04b729b30e56d68474ef',1,'glad.h']]],
  ['uniformblockbinding_2',['uniformBlockBinding',['../glad_8h.html#ac15d8775053e517f7961f1fbc8e41e9b',1,'glad.h']]],
  ['uniformblockindex_3',['uniformBlockIndex',['../glad_8h.html#adc30abe82647bc0cb76d2e37147524ba',1,'glad.h']]],
  ['uniformblockname_4',['uniformBlockName',['../glad_8h.html#a135be84cdb9422534a079f241afacfe9',1,'glad.h']]],
  ['uniformcount_5',['uniformCount',['../glad_8h.html#a1569175aef85efe8908df08118f1a22b',1,'glad.h']]],
  ['uniformindex_6',['uniformIndex',['../glad_8h.html#a920771c8e6c5f3c8d831f248650b8b54',1,'glad.h']]],
  ['uniformindices_7',['uniformIndices',['../glad_8h.html#a86e9db566123a4bbc7040edb52b6879b',1,'glad.h']]],
  ['uniformname_8',['uniformName',['../glad_8h.html#a32334347b3f569b7c8a44a78f2e4482c',1,'glad.h']]],
  ['uniformnames_9',['uniformNames',['../glad_8h.html#afe0812aefec2c73b39be63d240a6a6d1',1,'glad.h']]],
  ['units_10',['units',['../glad_8h.html#abfa9efe7c13ea1f8f0756f7d74b32958',1,'glad.h']]],
  ['uorder_11',['uorder',['../glad_8h.html#ab43abcff762493cadf40025621caba8f',1,'glad.h']]],
  ['usage_12',['usage',['../glad_8h.html#afb85c5d9b1bce96aa3b530d581194d1a',1,'glad.h']]],
  ['ustride_13',['ustride',['../glad_8h.html#a33731be23c667fb819c037e6fb645ad3',1,'glad.h']]]
];
