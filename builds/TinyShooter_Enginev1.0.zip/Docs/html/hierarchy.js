var hierarchy =
[
    [ "ApplicationV2", "class_application_v2.html", null ],
    [ "ComponentV2", "class_component_v2.html", [
      [ "MovementComponentV2", "class_movement_component_v2.html", null ],
      [ "SpriteComponentV2", "class_sprite_component_v2.html", null ],
      [ "SquareColliderComponentV2", "class_square_collider_component_v2.html", null ],
      [ "TransformComponentV2", "class_transform_component_v2.html", null ]
    ] ],
    [ "GameObjectV2", "class_game_object_v2.html", null ],
    [ "gladGLversionStruct", "structglad_g_lversion_struct.html", null ],
    [ "ResourceManagerV2", "class_resource_manager_v2.html", null ],
    [ "SceneV2", "class_scene_v2.html", null ],
    [ "SDLGraphicsProgramV2", "class_s_d_l_graphics_program_v2.html", null ]
];