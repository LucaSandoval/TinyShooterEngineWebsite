var annotated_dup =
[
    [ "ApplicationV2", "class_application_v2.html", "class_application_v2" ],
    [ "ComponentV2", "class_component_v2.html", "class_component_v2" ],
    [ "GameObjectV2", "class_game_object_v2.html", "class_game_object_v2" ],
    [ "gladGLversionStruct", "structglad_g_lversion_struct.html", null ],
    [ "MovementComponentV2", "class_movement_component_v2.html", "class_movement_component_v2" ],
    [ "ResourceManagerV2", "class_resource_manager_v2.html", "class_resource_manager_v2" ],
    [ "SceneV2", "class_scene_v2.html", "class_scene_v2" ],
    [ "SDLGraphicsProgramV2", "class_s_d_l_graphics_program_v2.html", "class_s_d_l_graphics_program_v2" ],
    [ "SpriteComponentV2", "class_sprite_component_v2.html", "class_sprite_component_v2" ],
    [ "SquareColliderComponentV2", "class_square_collider_component_v2.html", "class_square_collider_component_v2" ],
    [ "TransformComponentV2", "class_transform_component_v2.html", "class_transform_component_v2" ]
];