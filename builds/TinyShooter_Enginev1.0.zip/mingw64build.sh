# Run with sh mingw64build.sh

COMPILE="g++ -D MINGW -std=c++17 -shared -fPIC -static-libgcc -static-libstdc++ -I./include/ -I./../../../../SDL/include -I./pybind11/include/ `python3.11 -m pybind11 --includes` ./src/*.cpp -o tinyshooterengine.pyd `python3.11-config --ldflags` -L./../../../../build -lmingw32 -lSDL3 -mwindows -L libwinpthread-1.dll"


echo $COMPILE
echo "-------------------------------------------"
eval $COMPILE
